#!/usr/bin/env Rscript
library(tidyverse)
library(admixtools)

my_f2_dir <- 'path/to/f2s'
popList <- readLines('targetPops')

f2_blocks = f2_from_precomp(my_f2_dir, pops=popList)
opt_results = find_graphs(f2_blocks, numadmix = 0, outpop = 'YRI.DG')
saveRDS(opt_results, 'opt_results.rds')

winner = opt_results %>% slice_min(score, with_ties = FALSE)
saveRDS(winner, 'winner.rds')

qp = qpgraph(f2_blocks, winner$edges[[1]], return_fstats = TRUE)
w_res = qp$worst_residual

directory = getwd()
write(paste(sub(".*/admix_(\\d+)/.*", "\\1", directory), sub(".*/It_(\\d+)$", "\\1", directory), winner$score, w_res, winner$hash, sep = " "), "score.txt")

pdf(file = './winner.pdf', width = 60, height = 60)
plot_graph(winner$edges[[1]], textsize=5)
dev.off()
